import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

CONNECTORS = ["however", "therefore", "but", "moreover", "thus", "then", "after that",
              "although", "nevertheless", "furthermore", "in addition"]

# === Giải mã thông điệp ẩn dựa trên chữ cái đầu ===
def decode_hidden_message(text):
    sentences = [s.strip() for s in text.split('.') if s.strip()]
    hidden_binary = ""
    for sentence in sentences:
        if not sentence:
            continue
        first_char = sentence.strip()[0].upper()
        if first_char in "FGJLNPQRSZ":
            hidden_binary += "00"
        elif first_char in "BCDEK":
            hidden_binary += "01"
        elif first_char in "AMTUVWY":
            hidden_binary += "10"
        elif first_char in "HIOX":
            hidden_binary += "11"
    # Tách mỗi 8 bit thành ký tự
    message = ''.join([chr(int(hidden_binary[i:i+8], 2)) for i in range(0, len(hidden_binary), 8)])
    return message

# === Phân tích mức độ liên kết giữa các câu ===
def count_connectors(text):
    lower_text = text.lower()
    return sum(lower_text.count(conn) for conn in CONNECTORS)

def sentence_coherence_score(sentences):
    tfidf = TfidfVectorizer().fit_transform(sentences)
    score = 0
    comparisons = 0
    for i in range(len(sentences)-1):
        vec1 = tfidf[i]
        vec2 = tfidf[i+1]
        sim = cosine_similarity(vec1, vec2)[0][0]
        score += sim
        comparisons += 1
    return score / comparisons if comparisons > 0 else 0

# === Phát hiện và giải mã nếu nghi ngờ ===
def detect_and_decode(text, coherence_threshold=0.25, connector_threshold=2):
    sentences = [s.strip() for s in text.split('.') if s.strip()]
    connectors = count_connectors(text)
    coherence = sentence_coherence_score(sentences)

    print(f"Đánh giá văn bản:") 
    print(f"Mức độ liên kết giữa các câu (cosine): {coherence:.3f}")
    print(f"Số lượng từ nối tìm thấy: {connectors}")

    suspicious = coherence < coherence_threshold and connectors < connector_threshold
    if suspicious:
        print("Phát hiện: Văn bản có thể chứa thông điệp ẩn!")
        message = decode_hidden_message(text)
        print(f"Thông điệp được giải mã: '{message}'")
    else:
        print("Văn bản có vẻ tự nhiên, không có dấu hiệu giấu thông tin.")

# === Hàm chính ===
def main():
    try:
        with open("message.txt", "r", encoding="utf-8") as f:
            text = f.read()
    except FileNotFoundError:
        print("Không tìm thấy file 'message.txt'!")
        return

    detect_and_decode(text)

if __name__ == "__main__":
    main()

