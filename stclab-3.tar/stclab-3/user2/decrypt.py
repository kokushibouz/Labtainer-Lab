def decode_message(encoded_text):
    """Giải mã thông điệp bí mật từ văn bản đã mã hóa."""
    sentences = encoded_text.split('. ')
    binary_string = ''
    
    for sentence in sentences:
        if sentence.strip():
            first_char = sentence.strip()[0]
            if first_char in 'FGJLNPQRSZ':
                binary_string += '00'
            elif first_char in 'BCDEK':
                binary_string += '01'
            elif first_char in 'AMTUVWY':
                binary_string += '10'
            elif first_char in 'HIOX':
                binary_string += '11'
    
    return binary_string

def binary_to_secret_message(binary_string):
    """Chuyển đổi chuỗi bit nhị phân thành thông điệp bí mật."""
    # Loại bỏ bit '0' cuối cùng nếu độ dài chuỗi bit ban đầu là lẻ
    if len(binary_string) % 8 != 0:
        binary_string = binary_string[:-1]
    
    secret_message = ''
    for i in range(0, len(binary_string), 8):
        byte = binary_string[i:i+8]
        secret_message += chr(int(byte, 2))
    
    return secret_message

def main():
    with open("encrypt.txt", "r", encoding="utf-8") as file:
        encoded_text = file.read()
    
    binary_string = decode_message(encoded_text)
    secret_message = binary_to_secret_message(binary_string)
    
    print("Secret Message: ", secret_message)

if __name__ == "__main__":
    main()
