def secret_message_to_binary(secret_message):
    """Chuyển đổi thông điệp bí mật thành chuỗi bit nhị phân."""
    binary_string = ''.join(format(ord(char), '08b') for char in secret_message)
    return binary_string

def adjust_binary_length(binary_string):
    """Điều chỉnh độ dài chuỗi bit để đảm bảo là chẵn."""
    if len(binary_string) % 2 != 0:
        binary_string += '0'
    return binary_string

def text_to_uppercase(text):
    """Chuyển đổi tất cả các ký tự trong văn bản thành chữ hoa."""
    return text.upper()

def encode_message(binary_string, text):
    """Mã hóa thông điệp bí mật vào văn bản."""
    sentences = text.split('.')
    encoded_text = []
    binary_pairs = [binary_string[i:i+2] for i in range(0, len(binary_string), 2)]
    i = 0
    j = 0
    n = len(sentences)
    for pair in binary_pairs:
        for i in range(j,n):
            if sentences[i].strip():
                first_char = sentences[i].strip()[0]
                if (pair == '00' and first_char in 'FGJLNPQRSZ') or \
                   (pair == '01' and first_char in 'BCDEK') or \
                   (pair == '10' and first_char in 'AMTUVWY') or \
                   (pair == '11' and first_char in 'HIOX'):
                    encoded_text.append(sentences[i].strip())
                    j = i
                    break
    return '. '.join(encoded_text)

def main():
    secret_message = "ptit"
    with open("text.txt", "r", encoding="utf-8") as file:
        text = file.read()
    n=text.split(". ")
    binary_secret = secret_message_to_binary(secret_message)
    adjusted_binary = adjust_binary_length(binary_secret)
    uppercase_text = text_to_uppercase(text)
    encoded_text = encode_message(adjusted_binary, uppercase_text)
    with open("encrypt.txt", "w") as file:
        file.write(encoded_text)
    print("Done")
if __name__ == "__main__":
    main()
