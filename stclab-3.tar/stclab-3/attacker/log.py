from scapy.all import sniff, Raw
def packet_handler(packet):
    if packet.haslayer(Raw):
        payload = packet[Raw].load
        print(f"[LOG] Data FTP: {payload}")  
print("[*] Catching data FTP from user1 (172.22.2.10) to user2 (172.22.2.2)...")
sniff(iface="eth0", filter="tcp port 21", prn=packet_handler)

