#!/usr/bin/env python3
import tkinter as tk
from tkinter import filedialog, messagebox
import os

# ========== Hàm xử lý ==========
def secret_message_to_binary(secret_message):
    return ''.join(format(ord(char), '08b') for char in secret_message)

def adjust_binary_length(binary_string):
    return binary_string + '0' if len(binary_string) % 2 != 0 else binary_string

def text_to_uppercase(text):
    return text.upper()

def encode_message(binary_string, text):
    sentences = text.split('.')
    encoded_text = []
    binary_pairs = [binary_string[i:i+2] for i in range(0, len(binary_string), 2)]
    j = 0
    n = len(sentences)
    for pair in binary_pairs:
        for i in range(j, n):
            if sentences[i].strip():
                first_char = sentences[i].strip()[0]
                if (pair == '00' and first_char in 'FGJLNPQRSZ') or \
                   (pair == '01' and first_char in 'BCDEK') or \
                   (pair == '10' and first_char in 'AMTUVWY') or \
                   (pair == '11' and first_char in 'HIOX'):
                    encoded_text.append(sentences[i].strip())
                    j = i + 1
                    break
    return '. '.join(encoded_text)

def decode_message(encoded_text):
    sentences = encoded_text.split('. ')
    binary_string = ''
    for sentence in sentences:
        if sentence.strip():
            first_char = sentence.strip()[0]
            if first_char in 'FGJLNPQRSZ':
                binary_string += '00'
            elif first_char in 'BCDEK':
                binary_string += '01'
            elif first_char in 'AMTUVWY':
                binary_string += '10'
            elif first_char in 'HIOX':
                binary_string += '11'
    return binary_string

def binary_to_secret_message(binary_string):
    if len(binary_string) % 8 != 0:
        binary_string = binary_string[:-1]
    return ''.join(chr(int(binary_string[i:i+8], 2)) for i in range(0, len(binary_string), 8))

# ========== GUI ==========
class SecretMessageGUI:
    def __init__(self, master):
        self.master = master
        master.title("Steganography")
        self.mode = tk.StringVar(value="encode")

        self.secret_file = ""
        self.cover_file = ""
        self.decode_file = ""

        # === Widgets ===
        self.label_mode = tk.Label(master, text="Chọn chế độ:")
        self.label_mode.pack()

        self.mode_frame = tk.Frame(master)
        self.encode_radio = tk.Radiobutton(self.mode_frame, text="Mã hóa", variable=self.mode, value="encode", command=self.toggle_mode)
        self.decode_radio = tk.Radiobutton(self.mode_frame, text="Giải mã", variable=self.mode, value="decode", command=self.toggle_mode)
        self.encode_radio.pack(side="left", padx=10)
        self.decode_radio.pack(side="left", padx=10)
        self.mode_frame.pack(pady=5)

        # Chọn file thông điệp
        self.btn_secret = tk.Button(master, text="Chọn file chứa thông điệp", command=self.choose_secret_file)
        # Chọn file nền
        self.btn_cover = tk.Button(master, text="Chọn file nền", command=self.choose_cover_file)
        # Chọn file mã hóa để giải mã
        self.btn_decode_file = tk.Button(master, text="Chọn file cần giải mã", command=self.choose_decode_file)

        self.btn_secret.pack(pady=2)
        self.btn_cover.pack(pady=2)
        self.btn_decode_file.pack(pady=2)

        self.btn_execute = tk.Button(master, text="Thực hiện", command=self.perform_action)
        self.btn_execute.pack(pady=10)

        self.status_label = tk.Label(master, text="", fg="blue")
        self.status_label.pack()

        self.toggle_mode()

    def toggle_mode(self):
        self.status_label.config(text="")
        self.secret_file = ""
        self.cover_file = ""
        self.decode_file = ""
        if self.mode.get() == "encode":
            self.btn_secret.config(state="normal")
            self.btn_cover.config(state="normal")
            self.btn_decode_file.config(state="disabled")
        else:
            self.btn_secret.config(state="disabled")
            self.btn_cover.config(state="disabled")
            self.btn_decode_file.config(state="normal")

    def choose_secret_file(self):
        file = filedialog.askopenfilename(title="Chọn file chứa thông điệp", filetypes=[("Text files", "*.txt")])
        if file:
            self.secret_file = file
            self.status_label.config(text=f"Đã chọn thông điệp: {os.path.basename(file)}")

    def choose_cover_file(self):
        file = filedialog.askopenfilename(title="Chọn file văn bản nền", filetypes=[("Text files", "*.txt")])
        if file:
            self.cover_file = file
            self.status_label.config(text=f"Đã chọn văn bản nền: {os.path.basename(file)}")

    def choose_decode_file(self):
        file = filedialog.askopenfilename(title="Chọn file đã mã hóa", filetypes=[("Text files", "*.txt")])
        if file:
            self.decode_file = file
            self.status_label.config(text=f"Đã chọn để giải mã: {os.path.basename(file)}")

    def perform_action(self):
        try:
            if self.mode.get() == "encode":
                if not self.secret_file or not self.cover_file:
                    messagebox.showerror("Lỗi", "Vui lòng chọn cả 2 file: thông điệp và văn bản nền.")
                    return

                with open(self.secret_file, "r", encoding="utf-8") as f:
                    secret_message = f.read().strip()
                with open(self.cover_file, "r", encoding="utf-8") as f:
                    cover_text = f.read()

                binary_secret = secret_message_to_binary(secret_message)
                adjusted_binary = adjust_binary_length(binary_secret)
                upper_cover = text_to_uppercase(cover_text)
                encoded = encode_message(adjusted_binary, upper_cover)

                with open("encrypt.txt", "w", encoding="utf-8") as f:
                    f.write(encoded)

                messagebox.showinfo("Thành công", "Đã mã hóa thành công và lưu vào encrypt.txt!")

            else:
                if not self.decode_file:
                    messagebox.showerror("Lỗi", "Vui lòng chọn file mã hóa.")
                    return

                with open(self.decode_file, "r", encoding="utf-8") as f:
                    encoded_text = f.read()

                binary = decode_message(encoded_text)
                secret = binary_to_secret_message(binary)
                messagebox.showinfo("Thông điệp", f"Thông điệp là:\n{secret}")
        except Exception as e:
            messagebox.showerror("Lỗi", f"Đã xảy ra lỗi: {str(e)}")

# ========== Run ==========
if __name__ == "__main__":
    root = tk.Tk()
    app = SecretMessageGUI(root)
    root.geometry("460x360")
    root.mainloop()

