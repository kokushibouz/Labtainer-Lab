print("nhap vao pass word: ")
text=input()
if (text=="a"):
    print("Correct passwd")
else:
    print("Incorrect passwd")
